SIGMA fp -- fpSup Loader v3 card (fpSup-Merge v3)
firmware: SIGMA fp Ver.5.02 only

Copy everything in this folder to the root of the SD card.
The loader loads fpSup\NN*.BIN in name order; it skips every folder inside fpSup.
Diagnostics: \fpSup\LOAD.LOG

Instant Start: ON (power-switch restart reuses the RAM loader)
Fast Start: OFF
fpSup page: OFF

RUNS (fpSup\):
  32RESCUS.BIN fpsup-res-custom-v0.1.4test  -- thanks to Jose Hurtado
               data: OG2K, OG3K, OG3.5K (by Jose Hurtado), OG4K (by Jose Hurtado), S16 (by Jose Hurtado)

files:
  AutoRun.txt             3561 B  sha256=889800fa363c75bfe0d9da43da82312276388a8929748ce05221ce0da931bb4c
  fpSup/LOADER.BIN        8528 B  sha256=ab34813df3c9a662d54085cddc8373adb584ee8664ff60d0c4371456eaa55cd1
  fpSup/UI/0.BIN        114688 B  sha256=89cd5a002595ea0a22f7cbd5a05990612477dd5da2c2d561b9fad8a3aed7c6ea
  fpSup/UI/1.BIN         19712 B  sha256=48dddff9f4b9d2a352faf43e80afd18383fe0d48a3c0617a060b2b977d81f0fb
  fpSup/UI/2.BIN         19712 B  sha256=d5567299a7b695afa26090c124f941a15b3ca701b60a58629af45eb10943efbe
  fpSup/UI/3.BIN         19712 B  sha256=c1a5c9cc59528f7dbe88ee6a6631cb2c93c0ad4575234a29f7c271f9f48ccd2c
  fpSup/UI/4.BIN         19712 B  sha256=065a09b93c88784f0774ce819ae5f6fa3a5aba41d8c4e9ddd7e902e3b20921d3
  fpSup/32RESCUS.BIN    313216 B  sha256=d9a8e10050184424886afaca263279967ab2cc2c89314c44038fe4402a676355
  fpSup/RESCUS/OG2K.RCD    5216 B  sha256=8025ea96924b535f9b202b2f9ae65c81f7c66129bf4dfb5256c2a1d46b444ecf
  fpSup/RESCUS/OG3K.RCD    4244 B  sha256=f61a3861dba81d12f4a9eb7a0fc8cca249859ee4bc840dcc022b134d647b89ba
  fpSup/RESCUS/OG35K.RCD    7788 B  sha256=e5b5ba7a9535f45b597745e1bec5377dad4c4fa46aa11fb9fb6c53648f57a303
  fpSup/RESCUS/OG4K.RCD    3900 B  sha256=39a808f2189895dce66c93d283711b67327c3a2869ff25ea2b43af00492e6661
  fpSup/RESCUS/S16.RCD    7132 B  sha256=3e942889e4cfb47f5c0aba2d696544abcc9a8b76fd2848bc0b7feb275195afd4
