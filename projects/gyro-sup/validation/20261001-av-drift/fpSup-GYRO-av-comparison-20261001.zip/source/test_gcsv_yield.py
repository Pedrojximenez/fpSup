#!/usr/bin/env python3
"""Execute the optional GCSV scheduling diagnostic; no camera or media access.

Native delay and write calls are strict stubs.  These tests prove bytes, bounds,
call spacing and ABI, not real scheduling, audio capture or storage latency.
"""
import importlib.util
from pathlib import Path
import struct
import subprocess
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'fp_usb_shell'))
from armasm import assemble, symbols                              # noqa: E402
from test_gcsv_format import camera                               # noqa: E402

SOURCE = HERE / 'gcsv_task.S'
CANDIDATE = ('FPGYRO_FORMAT_YIELD_RECORDS=128',)
DELAY, WRITE = 0xC01F89C4, 0xC03660E8
POOL, CODE = 0x45000000, 0x45044000
INPUT, OUTPUT = 0x46000000, 0x47000003  # deliberately unaligned text
STACK, STOP, JOB = 0x10000000, 0x10100000, 0x46008000
FRAMEBUF, TEXT_BYTES = 0xC3757A7C, 0x22000

HAS_UNICORN = False
EMULATOR_REASON = 'Unicorn unavailable; ARM execution is unverified'
if importlib.util.find_spec('unicorn') is not None:
    probe = subprocess.run([sys.executable, '-B', '-c',
        'import unicorn; u=unicorn.Uc(unicorn.UC_ARCH_ARM,unicorn.UC_MODE_ARM); '
        'u.mem_map(4096,4096); u.mem_write(4096,bytes.fromhex("0000a0e1")); '
        'u.emu_start(4096,4100,count=1)'], capture_output=True, timeout=10)
    HAS_UNICORN = probe.returncode == 0
    EMULATOR_REASON = (f'Unicorn probe exited {probe.returncode}; host sandbox/JIT '
                       'blocked execution, so ARM execution is unverified')


def records(count):
    """Extremes, negative axes, and accelerometers on formatter boundaries."""
    values = (-32768, 32767, -10000, -1, 0, 1, 999, 10000)
    return [(values[i % 8], values[(i + 3) % 8],
             int(i % 53 == 0 or i % 128 == 0), values[(i + 5) % 8])
            for i in range(count)]


def reference(recs, start=0):
    lines = camera(recs)
    if start:
        lines = [f'{int(line.split(",", 1)[0]) + start},'
                 + line.split(',', 1)[1] for line in lines]
    return ''.join(line + '\n' for line in lines).encode()


class Formatter:
    """Execute only the actual assembled blob plus two declared native stubs."""
    def __init__(self, code, syms, limit=None):
        from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM, UC_HOOK_CODE
        from unicorn import arm_const as reg
        self.reg, self.syms = reg, syms
        self.uc = Uc(UC_ARCH_ARM, UC_MODE_ARM)
        for at, size in ((POOL, 0x100000), (INPUT, 0x10000),
                         (OUTPUT & ~0xFFF, 0x24000), (STACK, 0x10000),
                         (STOP, 0x1000), (FRAMEBUF & ~0xFFF, 0x1000),
                         (DELAY & ~0xFFF, 0x1000), (WRITE & ~0xFFF, 0x1000)):
            self.uc.mem_map(at, size)
        self.uc.mem_write(CODE, code)
        self.put32(FRAMEBUF, POOL)
        self.code_end = CODE + len(code)
        self.limit = limit
        self.delays, self.writes, self.consumed = [], [], 0
        self.since_yield, self.returned = 0, False
        self.uc.hook_add(UC_HOOK_CODE, self._code)

    def put32(self, address, value):
        self.uc.mem_write(address, struct.pack('<I', value))

    def state(self, name, value):
        self.put32(CODE + self.syms[name], value)

    def regread(self, n):
        return self.uc.reg_read(getattr(self.reg, f'UC_ARM_REG_R{n}'))

    def _code(self, uc, address, size, _data):
        if address == STOP:
            self.returned = True
            uc.emu_stop()
            return
        if address in (DELAY, WRITE):
            if uc.reg_read(self.reg.UC_ARM_REG_SP) % 8:
                raise AssertionError('unaligned stack at native call')
            lr = uc.reg_read(self.reg.UC_ARM_REG_LR)
            if address == DELAY:
                if self.regread(0) != 1:
                    raise AssertionError('delay must be positive 1 ms')
                if not self.since_yield:
                    raise AssertionError('delay without a consumed record')
                self.delays.append(self.since_yield)
                self.since_yield = 0
            else:
                self.writes.append(bytes(uc.mem_read(self.regread(1), self.regread(2))))
            for n in (0, 1, 2, 3, 12):
                uc.reg_write(getattr(self.reg, f'UC_ARM_REG_R{n}'), 0xBAD00000 + n)
            uc.reg_write(self.reg.UC_ARM_REG_R0, int(address == WRITE))
            cpsr = uc.reg_read(self.reg.UC_ARM_REG_CPSR)
            uc.reg_write(self.reg.UC_ARM_REG_CPSR, (cpsr & 0x0FFFFFFF) | 0xA0000000)
            uc.reg_write(self.reg.UC_ARM_REG_PC, lr)
            return
        if not CODE <= address < self.code_end:
            raise AssertionError(f'unmocked code at {address:#x}')
        instruction = struct.unpack('<I', uc.mem_read(address, 4))[0]
        if ((instruction & 0x0F000000) == 0x0B000000 or
                (instruction & 0x0FFFFFF0) == 0x012FFF30):
            if uc.reg_read(self.reg.UC_ARM_REG_SP) % 8:
                raise AssertionError('unaligned stack at ARM call')
        if address == CODE + self.syms['gcsv_record_consumed']:
            self.consumed += 1
            self.since_yield += 1
            if self.limit and self.since_yield > self.limit:
                raise AssertionError(f'more than {self.limit} records without delay')

    def call(self, name, args=(), job=None):
        self.returned, self.since_yield = False, 0
        saved = {n: 0x55550000 + n for n in range(4, 12)}
        if job is not None:
            saved[4] = job
        for n, value in saved.items():
            self.uc.reg_write(getattr(self.reg, f'UC_ARM_REG_R{n}'), value)
        for n, value in enumerate(args):
            self.uc.reg_write(getattr(self.reg, f'UC_ARM_REG_R{n}'), value)
        initial_sp = STACK + 0xFFF0
        self.uc.reg_write(self.reg.UC_ARM_REG_SP, initial_sp)
        self.uc.reg_write(self.reg.UC_ARM_REG_LR, STOP)
        # Supervisor task context, with IRQ and FIQ unmasked.
        self.uc.reg_write(self.reg.UC_ARM_REG_CPSR, 0x13)
        self.uc.emu_start(CODE + self.syms[name], STOP + 4, count=3000000)
        if not self.returned:
            raise AssertionError('formatter failed to return within instruction budget')
        if self.uc.reg_read(self.reg.UC_ARM_REG_SP) != initial_sp:
            raise AssertionError('SP was not restored')
        for n, value in saved.items():
            if self.regread(n) != value:
                raise AssertionError(f'callee-saved r{n} changed')
        return self.regread(0), self.regread(1)

    def format(self, recs, budget=TEXT_BYTES):
        packed = b''.join(struct.pack('<hhhh', *rec) for rec in recs)
        self.uc.mem_write(INPUT, packed)
        sentinel = b'\xA5' * (TEXT_BYTES + 8)
        self.uc.mem_write(OUTPUT - 3, sentinel)
        end, remaining = self.call('gcsv_format', (INPUT, len(recs), OUTPUT, OUTPUT + budget))
        if not OUTPUT <= end <= OUTPUT + budget:
            raise AssertionError('formatter exceeded its output budget')
        if bytes(self.uc.mem_read(OUTPUT - 3, 3)) != sentinel[:3]:
            raise AssertionError('formatter wrote before output')
        tail = bytes(self.uc.mem_read(end, TEXT_BYTES + 5 - (end - OUTPUT)))
        if tail != b'\xA5' * len(tail):
            raise AssertionError('formatter wrote beyond returned text')
        return bytes(self.uc.mem_read(OUTPUT, end - OUTPUT)), remaining

    def last(self):
        end, _ = self.call('gcsv_last', (OUTPUT,))
        return bytes(self.uc.mem_read(OUTPUT, end - OUTPUT))

    def stream(self, recs, chunk=2048, budget=TEXT_BYTES):
        out = bytearray()
        for at in range(0, len(recs), chunk):
            pending = recs[at:at + chunk]
            while pending:
                emitted, left = self.format(pending, budget)
                out.extend(emitted)
                if left == len(pending):
                    raise AssertionError('test budget permits no progress')
                pending = pending[len(pending) - left:] if left else []
        out.extend(self.last())
        return bytes(out)


@unittest.skipUnless(HAS_UNICORN, EMULATOR_REASON)
class YieldTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.current = assemble(SOURCE), symbols(SOURCE)
        cls.candidate = assemble(SOURCE, CANDIDATE), symbols(SOURCE, CANDIDATE)

    def machine(self, candidate=True):
        return Formatter(*(self.candidate if candidate else self.current),
                         limit=128 if candidate else None)

    def test_boundary_counts_and_exact_output(self):
        for n in (0, 1, 127, 128, 129, 2048):
            with self.subTest(records=n):
                recs = records(n)
                current, candidate = self.machine(False), self.machine()
                a, aleft = current.format(recs)
                b, bleft = candidate.format(recs)
                self.assertEqual((aleft, bleft), (0, 0))
                self.assertEqual(a + current.last(), reference(recs))
                self.assertEqual(b + candidate.last(), reference(recs))
                self.assertEqual(a, b)
                self.assertEqual(candidate.delays, [128] * (n // 128))
                self.assertEqual(current.delays, [])

    def test_rows_survive_blocks_tiny_odd_budgets_and_large_timestamps(self):
        recs = records(2177)
        for chunk, budget in ((2048, TEXT_BYTES), (127, 131), (129, 73), (53, 67)):
            with self.subTest(chunk=chunk, budget=budget):
                current, candidate = self.machine(False), self.machine()
                for machine in (current, candidate):
                    machine.state('g_g_row', 1000000000)
                want = reference(recs, start=1000000000)
                self.assertEqual(current.stream(recs, chunk, budget), want)
                self.assertEqual(candidate.stream(recs, chunk, budget), want)

    def test_insufficient_budget_consumes_nothing_and_never_delays(self):
        for budget in (0, 1, 31, 63):
            machine = self.machine()
            self.assertEqual(machine.format(records(129), budget), (b'', 129))
            self.assertEqual(machine.delays, [])
            self.assertEqual(machine.consumed, 0)

    def test_writer_keeps_one_write_per_whole_block(self):
        recs = records(2048)
        written = []
        for candidate in (False, True):
            machine = self.machine(candidate)
            machine.uc.mem_write(INPUT, b''.join(struct.pack('<hhhh', *r) for r in recs))
            machine.uc.mem_write(JOB, struct.pack('<6I', 0, 0, INPUT, len(recs) * 8, 0, 0))
            machine.state('g_g_text', OUTPUT)
            machine.state('g_t_fobj', 0x48000000)
            machine.call('writer_put', job=JOB)
            self.assertEqual(len(machine.writes), 1)
            self.assertEqual(machine.delays, [128] * 16 if candidate else [])
            self.assertEqual(machine.writes[0] + machine.last(), reference(recs))
            written.append(machine.writes[0])
        self.assertEqual(*written)

    def test_disabling_delay_is_caught_by_spacing_assertion(self):
        code, syms = self.candidate
        broken = bytearray(code)
        struct.pack_into('<I', broken, syms['gcsv_format_delay'], 0xE1A00000)  # nop
        machine = Formatter(bytes(broken), syms, limit=128)
        with self.assertRaisesRegex(AssertionError, 'more than 128 records'):
            machine.format(records(129))

    def test_base_bytes_ignore_diagnostic_define(self):
        base = ('FPGYRO_EDITION_BASE=1',)
        self.assertEqual(assemble(SOURCE, base), assemble(SOURCE, base + CANDIDATE))


if __name__ == '__main__':
    unittest.main(verbosity=2)
